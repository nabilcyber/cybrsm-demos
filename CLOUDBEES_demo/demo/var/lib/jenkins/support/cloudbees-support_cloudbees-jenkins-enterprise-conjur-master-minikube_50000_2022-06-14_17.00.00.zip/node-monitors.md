Node monitors
=============
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: null
Architecture
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 6.164GB left on /var/lib/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Memory:139/6962MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 6.164GB left on /tmp/tmp.TuVI0Fliqh.
Response Time
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: 0ms
