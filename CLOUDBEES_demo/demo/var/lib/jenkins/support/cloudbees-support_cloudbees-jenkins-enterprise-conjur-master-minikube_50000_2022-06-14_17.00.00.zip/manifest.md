CloudBees Support Bundle Manifest
=================================

Generated on 2022-06-14 17:00:00.173+0000

Requested components:

  * CloudBees Assurance Program

      - `cap/beekeeper.md`

      - `cap/properties.md`

  * Agent Configuration File

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cloudbees.analytics.gatherer.RandomPersistentInstanceId.xml`

      - `jenkins-root-configuration-files/com.cloudbees.hudson.plugins.folder.config.AbstractFolderConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.ha.plugin.HAGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugin.metrics.views.Alerter.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.advisor.AdvisorGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.github_reporting.config.ReporterGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.license.RegistrationStateConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.platform.PlatformConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.opscenter.client.plugin.OperationsCenterRootAction.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.DAVStore.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.SftpStore.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.model.UsageStatisticsCloudBees.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/io.jenkins.plugins.junit.storage.JunitTestResultStorageConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.fingerprints.GlobalFingerprintConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.GlobalBuildDiscarderConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.ResourceDomainConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.tasks.filters.EnvVarsFilterGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.telemetry.Correlator.xml`

      - `jenkins-root-configuration-files/license.xml`

      - `jenkins-root-configuration-files/nectar-rbac.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.conjur.jenkins.configuration.GlobalConjurConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.github_branch_source.GitHubConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.GlobalDefaultFlowDurabilityLevel.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

  * About browser

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Controller Custom Log Recorders

  * Dump agent export tables (could reveal some memory leaks)

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Garbage Collection Logs

  * Controller Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Agent JVM process system metrics (Linux only)

  * Controller JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Controller Log Recorders

      - `nodes/master/logs/all_2022-06-14_15.56.35.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/built-in/gnuplot`

      - `load-stats/label/built-in/hour.csv`

      - `load-stats/label/built-in/min.csv`

      - `load-stats/label/built-in/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Controller Other Log Recorders

  * Reverse Proxy

      - `reverse-proxy.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

  * Agent Launch Logs

  * Agent Log Recorders

  * Agent system configuration (Linux only)

  * Controller system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

  * Controller Task Log Recorders

      - `task-logs/Bundle Upload.log`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/SharedConfigurationSynchronizer.log`

      - `task-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log`

      - `task-logs/health-checker.log`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `users/count.md`

  * Slow Request Records

  * Thread dumps on high CPU usage

  * Deadlock Records

  * Operations Center Connector Logs

