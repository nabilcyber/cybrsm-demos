Monitors
========

`com.cloudbees.jenkins.plugins.advisor.Reminder`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
