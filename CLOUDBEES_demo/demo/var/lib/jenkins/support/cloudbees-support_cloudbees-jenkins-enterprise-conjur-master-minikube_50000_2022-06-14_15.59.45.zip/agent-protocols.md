Active protocols
================

 * `Diagnostic-Ping`: Diagnostic-Ping
    * Deprecated: false
    * Required: false
    * Opt In: false
 * `OperationsCenter2`: OperationsCenter2
    * Deprecated: false
    * Required: false
    * Opt In: false
 * `Ping`: Ping protocol
    * Deprecated: false
    * Required: true
    * Opt In: false
 * `JNLP4-connect`: Inbound TCP Agent Protocol/4 (TLS encryption)
    * Deprecated: false
    * Required: false
    * Opt In: false

Inactive protocols
==================

