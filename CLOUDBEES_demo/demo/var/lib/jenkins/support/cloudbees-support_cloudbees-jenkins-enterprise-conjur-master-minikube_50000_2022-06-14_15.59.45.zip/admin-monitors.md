Monitors
========

`com.cloudbees.jenkins.plugins.administrative_monitors.SystemJvmMonitor`
--------------
(active and enabled)

`com.cloudbees.jenkins.plugins.advisor.Reminder`
--------------
(active and enabled)

`jenkins.diagnostics.ControllerExecutorsNoAgents`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
