# Configuration

WAR Envelope detected [cje-2.332.3.4]
Installed Envelope detected [cje-2.332.3.4]
CloudBees Assurance Program enabled: true
Allow automatic upgrades of individual plugins on startup: false
Allow automatic downgrades of individual plugins on startup: false
Notify when security warnings affecting the core are detected: true
Notify when security warnings affecting plugins are detected: true

# Report

SUCCESS - Beekeeper Upgrade Assistant enabled on version 2.332.3.4.

## Items Requiring Attention

## Valid Items

* PLUGIN JavaScript GUI Lib: ACE Editor bundle plugin (ace-editor)
    * Description: Correctly installed at version 1.1
    * Action: No action needed.

* PLUGIN Jenkins Apache HttpComponents Client 4.x API Plugin (apache-httpcomponents-client-4-api)
    * Description: Correctly installed at version 4.5.13-1.0
    * Action: No action needed.

* PLUGIN CloudBees AWS Credentials Plugin (aws-credentials)
    * Description: Correctly installed at version 191.vcb_f183ce58b_9
    * Action: No action needed.

* PLUGIN Amazon Web Services SDK :: EC2 (aws-java-sdk-ec2)
    * Description: Correctly installed at version 1.12.163-315.v2b_716ec8e4df
    * Action: No action needed.

* PLUGIN Amazon Web Services SDK :: Minimal (aws-java-sdk-minimal)
    * Description: Correctly installed at version 1.12.163-315.v2b_716ec8e4df
    * Action: No action needed.

* PLUGIN Common API for Blue Ocean (blueocean-commons)
    * Description: Correctly installed at version 1.25.4
    * Action: No action needed.

* PLUGIN Bootstrap 4 API Plugin (bootstrap4-api)
    * Description: Correctly installed at version 4.6.0-3
    * Action: No action needed.

* PLUGIN Bootstrap 5 API Plugin (bootstrap5-api)
    * Description: Correctly installed at version 5.1.3-6
    * Action: No action needed.

* PLUGIN bouncycastle API Plugin (bouncycastle-api)
    * Description: Correctly installed at version 2.25
    * Action: No action needed.

* PLUGIN Branch API Plugin (branch-api)
    * Description: Correctly installed at version 2.1044.v2c007e51b_87f
    * Action: No action needed.

* PLUGIN Caffeine API Plugin (caffeine-api)
    * Description: Correctly installed at version 2.9.2-29.v717aac953ff3
    * Action: No action needed.

* PLUGIN Checks API plugin (checks-api)
    * Description: Correctly installed at version 1.7.2
    * Action: No action needed.

* PLUGIN CloudBees Administrative Monitors Plugin (cloudbees-administrative-monitors)
    * Description: Correctly installed at version 1.0.3
    * Action: No action needed.

* PLUGIN CloudBees Analytics Plugin (cloudbees-analytics)
    * Description: Correctly installed at version 1.41
    * Action: No action needed.

* PLUGIN Beekeeper Upgrade Assistant Plugin (cloudbees-assurance)
    * Description: Correctly installed at version 2.276.0.18
    * Action: No action needed.

* PLUGIN CloudBees Blue Ocean Default Theme (cloudbees-blueocean-default-theme)
    * Description: Correctly installed at version 0.8
    * Action: No action needed.

* PLUGIN Folders Plugin (cloudbees-folder)
    * Description: Correctly installed at version 6.714.v79e858ef76a_2
    * Action: No action needed.

* PLUGIN CloudBees Folders Plus Plugin (cloudbees-folders-plus)
    * Description: Correctly installed at version 3.26
    * Action: No action needed.

* PLUGIN CloudBees SCM Reporting Plugin (cloudbees-github-reporting)
    * Description: Correctly installed at version 1.28
    * Action: No action needed.

* PLUGIN CloudBees Groovy View Plugin (cloudbees-groovy-view)
    * Description: Correctly installed at version 1.14
    * Action: No action needed.

* PLUGIN CloudBees High Availability Management plugin (cloudbees-ha)
    * Description: Correctly installed at version 4.38
    * Action: No action needed.

* PLUGIN Jenkins Health Advisor by CloudBees (cloudbees-jenkins-advisor)
    * Description: Correctly installed at version 3.3.2
    * Action: No action needed.

* PLUGIN CloudBees Fast Archiving Plugin (cloudbees-jsync-archiver)
    * Description: Correctly installed at version 5.23
    * Action: No action needed.

* PLUGIN CloudBees License Manager (cloudbees-license)
    * Description: Correctly installed at version 9.64
    * Action: No action needed.

* PLUGIN CloudBees Monitoring Plugin (cloudbees-monitoring)
    * Description: Correctly installed at version 2.13
    * Action: No action needed.

* PLUGIN CloudBees Nodes Plus Plugin (cloudbees-nodes-plus)
    * Description: Correctly installed at version 1.23
    * Action: No action needed.

* PLUGIN CloudBees Platform Common Plugin (cloudbees-platform-common)
    * Description: Correctly installed at version 1.17
    * Action: No action needed.

* PLUGIN CloudBees SSH Build Agents Plugin (cloudbees-ssh-slaves)
    * Description: Correctly installed at version 2.16
    * Action: No action needed.

* PLUGIN CloudBees Support Plugin (cloudbees-support)
    * Description: Correctly installed at version 3.28
    * Action: No action needed.

* PLUGIN CloudBees Template Plugin (cloudbees-template)
    * Description: Correctly installed at version 4.54
    * Action: No action needed.

* PLUGIN CloudBees Update Center Data API (cloudbees-uc-data-api)
    * Description: Correctly installed at version 4.50
    * Action: No action needed.

* PLUGIN CloudBees Unified UI Plugin (cloudbees-unified-ui)
    * Description: Correctly installed at version 1.21
    * Action: No action needed.

* PLUGIN CloudBees View Creation Filter Plugin (cloudbees-view-creation-filter)
    * Description: Correctly installed at version 1.9
    * Action: No action needed.

* PLUGIN CloudBees Pipeline: Templates Plugin (cloudbees-workflow-template)
    * Description: Correctly installed at version 3.16
    * Action: No action needed.

* PLUGIN CloudBees Pipeline Stage View Extensions (cloudbees-workflow-ui)
    * Description: Correctly installed at version 2.7
    * Action: No action needed.

* PLUGIN Command Agent Launcher Plugin (command-launcher)
    * Description: Correctly installed at version 1.6
    * Action: No action needed.

* PLUGIN Credentials Plugin (credentials)
    * Description: Correctly installed at version 1087.1089.v2f1b_9a_b_040e4
    * Action: No action needed.

* PLUGIN Credentials Binding Plugin (credentials-binding)
    * Description: Correctly installed at version 1.27.1
    * Action: No action needed.

* PLUGIN Display URL API (display-url-api)
    * Description: Correctly installed at version 2.3.6
    * Action: No action needed.

* PLUGIN Durable Task Plugin (durable-task)
    * Description: Correctly installed at version 495.v29cd95ec10f2
    * Action: No action needed.

* PLUGIN ECharts API Plugin (echarts-api)
    * Description: Correctly installed at version 5.3.0-2
    * Action: No action needed.

* PLUGIN Email Extension Plugin (email-ext)
    * Description: Correctly installed at version 2.87
    * Action: No action needed.

* PLUGIN Font Awesome API Plugin (font-awesome-api)
    * Description: Correctly installed at version 6.0.0-1
    * Action: No action needed.

* PLUGIN Git plugin (git)
    * Description: Correctly installed at version 4.11.2
    * Action: No action needed.

* PLUGIN Jenkins Git client plugin (git-client)
    * Description: Correctly installed at version 3.11.0
    * Action: No action needed.

* PLUGIN Jenkins GIT server Plugin (git-server)
    * Description: Correctly installed at version 1.10
    * Action: No action needed.

* PLUGIN GitHub plugin (github)
    * Description: Correctly installed at version 1.34.3
    * Action: No action needed.

* PLUGIN GitHub API Plugin (github-api)
    * Description: Correctly installed at version 1.301-378.v9807bd746da5
    * Action: No action needed.

* PLUGIN GitHub Branch Source Plugin (github-branch-source)
    * Description: Correctly installed at version 1598.v91207e9f9b_4a_
    * Action: No action needed.

* PLUGIN Gradle Plugin (gradle)
    * Description: Correctly installed at version 1.38
    * Action: No action needed.

* PLUGIN JavaScript GUI Lib: Handlebars bundle plugin (handlebars)
    * Description: Correctly installed at version 3.0.8
    * Action: No action needed.

* PLUGIN CloudBees Backup Plugin (infradna-backup)
    * Description: Correctly installed at version 3.38.49
    * Action: No action needed.

* PLUGIN Jackson 2 API Plugin (jackson2-api)
    * Description: Correctly installed at version 2.13.2.20220328-273.v11d70a_b_a_1a_52
    * Action: No action needed.

* PLUGIN JavaBeans Activation Framework (JAF) API (javax-activation-api)
    * Description: Correctly installed at version 1.2.0-2
    * Action: No action needed.

* PLUGIN JavaMail API (javax-mail-api)
    * Description: Correctly installed at version 1.6.2-5
    * Action: No action needed.

* PLUGIN JAXB plugin (jaxb)
    * Description: Correctly installed at version 2.3.0.1
    * Action: No action needed.

* PLUGIN Oracle Java SE Development Kit Installer Plugin (jdk-tool)
    * Description: Correctly installed at version 1.5
    * Action: No action needed.

* PLUGIN Java JSON Web Token (JJWT) Plugin (jjwt-api)
    * Description: Correctly installed at version 0.11.2-9.c8b45b8bb173
    * Action: No action needed.

* PLUGIN JQuery3 API Plugin (jquery3-api)
    * Description: Correctly installed at version 3.6.0-2
    * Action: No action needed.

* PLUGIN Jenkins JSch dependency plugin (jsch)
    * Description: Correctly installed at version 0.1.55.2
    * Action: No action needed.

* PLUGIN JUnit Plugin (junit)
    * Description: Correctly installed at version 1.53
    * Action: No action needed.

* PLUGIN LDAP Plugin (ldap)
    * Description: Correctly installed at version 2.8
    * Action: No action needed.

* PLUGIN Jenkins Mailer Plugin (mailer)
    * Description: Correctly installed at version 408.vd726a_1130320
    * Action: No action needed.

* PLUGIN MapDB API Plugin (mapdb-api)
    * Description: Correctly installed at version 1.0.9.0
    * Action: No action needed.

* PLUGIN Matrix Project Plugin (matrix-project)
    * Description: Correctly installed at version 758.v7a_ea_491852f3
    * Action: No action needed.

* PLUGIN Metrics Plugin (metrics)
    * Description: Correctly installed at version 4.1.6.1
    * Action: No action needed.

* PLUGIN JavaScript GUI Lib: Moment.js bundle plugin (momentjs)
    * Description: Correctly installed at version 1.1.1
    * Action: No action needed.

* PLUGIN CloudBees Jenkins Enterprise License Entitlement Check (nectar-license)
    * Description: Correctly installed at version 8.39
    * Action: No action needed.

* PLUGIN CloudBees Role-Based Access Control Plugin (nectar-rbac)
    * Description: Correctly installed at version 5.69
    * Action: No action needed.

* PLUGIN Node Iterator API Plugin (node-iterator-api)
    * Description: Correctly installed at version 1.5.1
    * Action: No action needed.

* PLUGIN OkHttp Plugin (okhttp-api)
    * Description: Correctly installed at version 4.9.2-20211102
    * Action: No action needed.

* PLUGIN Operations Center Agent (operations-center-agent)
    * Description: Correctly installed at version 2.332.0.1
    * Action: No action needed.

* PLUGIN Operations Center Client Plugin (operations-center-client)
    * Description: Correctly installed at version 2.332.0.1
    * Action: No action needed.

* PLUGIN Operations Center Cloud (operations-center-cloud)
    * Description: Correctly installed at version 2.332.0.3
    * Action: No action needed.

* PLUGIN Operations Center Context (operations-center-context)
    * Description: Correctly installed at version 2.332.0.5
    * Action: No action needed.

* PLUGIN Pipeline: Build Step (pipeline-build-step)
    * Description: Correctly installed at version 2.17
    * Action: No action needed.

* PLUGIN Pipeline Graph Analysis Plugin (pipeline-graph-analysis)
    * Description: Correctly installed at version 188.v3a01e7973f2c
    * Action: No action needed.

* PLUGIN Pipeline: Input Step (pipeline-input-step)
    * Description: Correctly installed at version 447.v95e5a_6e3502a_
    * Action: No action needed.

* PLUGIN Pipeline: Milestone Step (pipeline-milestone-step)
    * Description: Correctly installed at version 100.v60a_03cd446e1
    * Action: No action needed.

* PLUGIN Pipeline: Model API (pipeline-model-api)
    * Description: Correctly installed at version 2.2075.vce74e77b_ce40
    * Action: No action needed.

* PLUGIN Pipeline: Declarative (pipeline-model-definition)
    * Description: Correctly installed at version 2.2075.vce74e77b_ce40
    * Action: No action needed.

* PLUGIN Pipeline: Declarative Extension Points API (pipeline-model-extensions)
    * Description: Correctly installed at version 2.2075.vce74e77b_ce40
    * Action: No action needed.

* PLUGIN Pipeline: REST API Plugin (pipeline-rest-api)
    * Description: Correctly installed at version 2.23
    * Action: No action needed.

* PLUGIN Pipeline: Stage Step (pipeline-stage-step)
    * Description: Correctly installed at version 291.vf0a8a7aeeb50
    * Action: No action needed.

* PLUGIN Pipeline: Stage Tags Metadata (pipeline-stage-tags-metadata)
    * Description: Correctly installed at version 2.2075.vce74e77b_ce40
    * Action: No action needed.

* PLUGIN Pipeline: Stage View Plugin (pipeline-stage-view)
    * Description: Correctly installed at version 2.23
    * Action: No action needed.

* PLUGIN Plain Credentials Plugin (plain-credentials)
    * Description: Correctly installed at version 1.8
    * Action: No action needed.

* PLUGIN Plugin Utilities API Plugin (plugin-util-api)
    * Description: Correctly installed at version 2.16.0
    * Action: No action needed.

* PLUGIN Popper.js API Plugin (popper-api)
    * Description: Correctly installed at version 1.16.1-2
    * Action: No action needed.

* PLUGIN Popper.js 2 API Plugin (popper2-api)
    * Description: Correctly installed at version 2.11.5-1
    * Action: No action needed.

* PLUGIN SCM API Plugin (scm-api)
    * Description: Correctly installed at version 595.vd5a_df5eb_0e39
    * Action: No action needed.

* PLUGIN Script Security Plugin (script-security)
    * Description: Correctly installed at version 1145.1148.vf6d17a_a_a_eef6
    * Action: No action needed.

* PLUGIN Snakeyaml API Plugin (snakeyaml-api)
    * Description: Correctly installed at version 1.29.1
    * Action: No action needed.

* PLUGIN SSH Credentials Plugin (ssh-credentials)
    * Description: Correctly installed at version 1.19
    * Action: No action needed.

* PLUGIN SSH server (sshd)
    * Description: Correctly installed at version 3.1.0
    * Action: No action needed.

* PLUGIN Structs Plugin (structs)
    * Description: Correctly installed at version 308.v852b473a2b8c
    * Action: No action needed.

* PLUGIN Support Core Plugin (support-core)
    * Description: Correctly installed at version 1148.vedff8cb_56a_da_
    * Action: No action needed.

* PLUGIN Token Macro Plugin (token-macro)
    * Description: Correctly installed at version 285.vff7645a_56ff0
    * Action: No action needed.

* PLUGIN Trilead API Plugin (trilead-api)
    * Description: Correctly installed at version 1.57.v6e90e07157e1
    * Action: No action needed.

* PLUGIN User Activity Monitoring Plugin (user-activity-monitoring)
    * Description: Correctly installed at version 1.5
    * Action: No action needed.

* PLUGIN Variant Plugin (variant)
    * Description: Correctly installed at version 1.4
    * Action: No action needed.

* PLUGIN Pipeline (workflow-aggregator)
    * Description: Correctly installed at version 2.5
    * Action: No action needed.

* PLUGIN Pipeline: API (workflow-api)
    * Description: Correctly installed at version 1143.v2d42f1e9dea_5
    * Action: No action needed.

* PLUGIN Pipeline: Basic Steps (workflow-basic-steps)
    * Description: Correctly installed at version 941.vdfe1b_a_132c64
    * Action: No action needed.

* PLUGIN Pipeline: Groovy (workflow-cps)
    * Description: Correctly installed at version 2683.2687.vb_0cc3f973f06
    * Action: No action needed.

* PLUGIN CloudBees Pipeline: Groovy Checkpoint Plugin (workflow-cps-checkpoint)
    * Description: Correctly installed at version 2.11
    * Action: No action needed.

* PLUGIN Pipeline: Shared Groovy Libraries (workflow-cps-global-lib)
    * Description: Correctly installed at version 566.vd0a_a_3334a_555
    * Action: No action needed.

* PLUGIN Pipeline: Nodes and Processes (workflow-durable-task-step)
    * Description: Correctly installed at version 1128.v8c259d125340
    * Action: No action needed.

* PLUGIN Pipeline: Job (workflow-job)
    * Description: Correctly installed at version 1174.1176.va_29023983d67
    * Action: No action needed.

* PLUGIN Pipeline: Multibranch (workflow-multibranch)
    * Description: Correctly installed at version 711.vdfef37cda_816
    * Action: No action needed.

* PLUGIN Pipeline: SCM Step (workflow-scm-step)
    * Description: Correctly installed at version 2.13
    * Action: No action needed.

* PLUGIN Pipeline: Step API (workflow-step-api)
    * Description: Correctly installed at version 622.vb_8e7c15b_c95a_
    * Action: No action needed.

* PLUGIN Pipeline: Supporting APIs (workflow-support)
    * Description: Correctly installed at version 817.v58126df57338
    * Action: No action needed.

## Plugin Catalog

Not installed
