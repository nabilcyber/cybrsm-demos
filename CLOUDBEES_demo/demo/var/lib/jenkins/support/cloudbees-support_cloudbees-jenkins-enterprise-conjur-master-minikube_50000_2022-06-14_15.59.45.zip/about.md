Jenkins
=======

Version details
---------------

  * Version: `2.332.3.4`
  * Instance ID: `d36bbbfd69d5ea9e18e44aa74c84f4f4`
  * Mode:    WAR
  * Url:     http://conjur-master-minikube:50000/
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Private Build
      - Version:          1.8.0&#95;312
      - Maximum memory:   1.51 GB (1623719936)
      - Allocated memory: 707.50 MB (741867520)
      - Free memory:      335.14 MB (351417496)
      - In-use memory:    372.36 MB (390450024)
      - GC strategy:      ParallelGC
      - Available CPUs:   2
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Private Build
      - Version: 25.312-b07
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.19.202
      - Distribution: Ubuntu 20.04.4 LTS
  * Process ID: 56 (0x38)
  * Process started: 2022-06-14 15:56:15.722+0000
  * Process uptime: 3 min 30 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dcb.distributable.name=Debian`
      - arg[2]: `-Dcb.distributable.commit_sha=c95df68aba7472a024dbdaf0db072b1b1073ab87`
      - arg[3]: `-Djava.io.tmpdir=/tmp/tmp.TuVI0Fliqh`

Remoting details
---------------

  * Embedded Version: `4.13`
  * Minimum Supported Version: `3.14`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * apache-httpcomponents-client-4-api:4.5.13-1.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * aws-credentials:191.vcb_f183ce58b_9 'CloudBees AWS Credentials Plugin'
  * aws-java-sdk-ec2:1.12.163-315.v2b_716ec8e4df 'Amazon Web Services SDK :: EC2'
  * aws-java-sdk-minimal:1.12.163-315.v2b_716ec8e4df 'Amazon Web Services SDK :: Minimal'
  * blueocean-commons:1.25.4 'Common API for Blue Ocean'
  * bootstrap4-api:4.6.0-3 'Bootstrap 4 API Plugin'
  * bootstrap5-api:5.1.3-6 'Bootstrap 5 API Plugin'
  * bouncycastle-api:2.25 'bouncycastle API Plugin'
  * branch-api:2.1044.v2c007e51b_87f 'Branch API Plugin'
  * caffeine-api:2.9.2-29.v717aac953ff3 'Caffeine API Plugin'
  * checks-api:1.7.2 'Checks API plugin'
  * cloudbees-administrative-monitors:1.0.3 'CloudBees Administrative Monitors Plugin'
  * cloudbees-analytics:1.41 'CloudBees Analytics Plugin'
  * cloudbees-assurance:2.276.0.18 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-blueocean-default-theme:0.8 'CloudBees Blue Ocean Default Theme'
  * cloudbees-folder:6.714.v79e858ef76a_2 'Folders Plugin'
  * cloudbees-folders-plus:3.26 'CloudBees Folders Plus Plugin'
  * cloudbees-github-reporting:1.28 'CloudBees SCM Reporting Plugin'
  * cloudbees-groovy-view:1.14 'CloudBees Groovy View Plugin'
  * cloudbees-ha:4.38 'CloudBees High Availability Management plugin'
  * cloudbees-jenkins-advisor:3.3.2 'Jenkins Health Advisor by CloudBees'
  * cloudbees-jsync-archiver:5.23 'CloudBees Fast Archiving Plugin'
  * cloudbees-license:9.64 'CloudBees License Manager'
  * cloudbees-monitoring:2.13 'CloudBees Monitoring Plugin'
  * cloudbees-nodes-plus:1.23 'CloudBees Nodes Plus Plugin'
  * cloudbees-platform-common:1.17 'CloudBees Platform Common Plugin'
  * cloudbees-ssh-slaves:2.16 'CloudBees SSH Build Agents Plugin'
  * cloudbees-support:3.28 'CloudBees Support Plugin'
  * cloudbees-template:4.54 'CloudBees Template Plugin'
  * cloudbees-uc-data-api:4.50 'CloudBees Update Center Data API'
  * cloudbees-unified-ui:1.21 'CloudBees Unified UI Plugin'
  * cloudbees-view-creation-filter:1.9 'CloudBees View Creation Filter Plugin'
  * cloudbees-workflow-template:3.16 'CloudBees Pipeline: Templates Plugin'
  * cloudbees-workflow-ui:2.7 'CloudBees Pipeline Stage View Extensions'
  * command-launcher:1.6 'Command Agent Launcher Plugin'
  * conjur-credentials:1.0.12 'Conjur Secrets Plugin'
  * credentials:1087.1089.v2f1b_9a_b_040e4 'Credentials Plugin'
  * credentials-binding:1.27.1 'Credentials Binding Plugin'
  * display-url-api:2.3.6 'Display URL API'
  * durable-task:495.v29cd95ec10f2 'Durable Task Plugin'
  * echarts-api:5.3.0-2 'ECharts API Plugin'
  * email-ext:2.87 'Email Extension Plugin'
  * font-awesome-api:6.0.0-1 'Font Awesome API Plugin'
  * git:4.11.2 'Git plugin'
  * git-client:3.11.0 'Jenkins Git client plugin'
  * git-server:1.10 'Jenkins GIT server Plugin'
  * github:1.34.3 'GitHub plugin'
  * github-api:1.301-378.v9807bd746da5 'GitHub API Plugin'
  * github-branch-source:1598.v91207e9f9b_4a_ 'GitHub Branch Source Plugin'
  * gradle:1.38 'Gradle Plugin'
  * handlebars:3.0.8 'JavaScript GUI Lib: Handlebars bundle plugin'
  * infradna-backup:3.38.49 'CloudBees Backup Plugin'
  * jackson2-api:2.13.2.20220328-273.v11d70a_b_a_1a_52 'Jackson 2 API Plugin'
  * javax-activation-api:1.2.0-2 'JavaBeans Activation Framework (JAF) API'
  * javax-mail-api:1.6.2-5 'JavaMail API'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.5 'Oracle Java SE Development Kit Installer Plugin'
  * jjwt-api:0.11.2-9.c8b45b8bb173 'Java JSON Web Token (JJWT) Plugin'
  * jquery3-api:3.6.0-2 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.53 'JUnit Plugin'
  * ldap:2.8 'LDAP Plugin'
  * mailer:408.vd726a_1130320 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-project:758.v7a_ea_491852f3 'Matrix Project Plugin'
  * metrics:4.1.6.1 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nectar-license:8.39 'CloudBees Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:5.69 'CloudBees Role-Based Access Control Plugin'
  * node-iterator-api:1.5.1 'Node Iterator API Plugin'
  * okhttp-api:4.9.2-20211102 'OkHttp Plugin'
  * operations-center-agent:2.332.0.1 'Operations Center Agent'
  * operations-center-client:2.332.0.1 'Operations Center Client Plugin'
  * operations-center-cloud:2.332.0.3 'Operations Center Cloud'
  * operations-center-context:2.332.0.5 'Operations Center Context'
  * pipeline-build-step:2.17 'Pipeline: Build Step'
  * pipeline-graph-analysis:188.v3a01e7973f2c 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:447.v95e5a_6e3502a_ 'Pipeline: Input Step'
  * pipeline-milestone-step:100.v60a_03cd446e1 'Pipeline: Milestone Step'
  * pipeline-model-api:2.2075.vce74e77b_ce40 'Pipeline: Model API'
  * pipeline-model-definition:2.2075.vce74e77b_ce40 'Pipeline: Declarative'
  * pipeline-model-extensions:2.2075.vce74e77b_ce40 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.23 'Pipeline: REST API Plugin'
  * pipeline-stage-step:291.vf0a8a7aeeb50 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:2.2075.vce74e77b_ce40 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.23 'Pipeline: Stage View Plugin'
  * plain-credentials:1.8 'Plain Credentials Plugin'
  * plugin-util-api:2.16.0 'Plugin Utilities API Plugin'
  * popper-api:1.16.1-2 'Popper.js API Plugin'
  * popper2-api:2.11.5-1 'Popper.js 2 API Plugin'
  * scm-api:595.vd5a_df5eb_0e39 'SCM API Plugin'
  * script-security:1145.1148.vf6d17a_a_a_eef6 'Script Security Plugin'
  * snakeyaml-api:1.29.1 'Snakeyaml API Plugin'
  * ssh-credentials:1.19 'SSH Credentials Plugin'
  * sshd:3.1.0 'SSH server'
  * structs:308.v852b473a2b8c 'Structs Plugin'
  * support-core:1148.vedff8cb_56a_da_ 'Support Core Plugin'
  * token-macro:285.vff7645a_56ff0 'Token Macro Plugin'
  * trilead-api:1.57.v6e90e07157e1 'Trilead API Plugin'
  * user-activity-monitoring:1.5 'User Activity Monitoring Plugin'
  * variant:1.4 'Variant Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:1143.v2d42f1e9dea_5 'Pipeline: API'
  * workflow-basic-steps:941.vdfe1b_a_132c64 'Pipeline: Basic Steps'
  * workflow-cps:2683.2687.vb_0cc3f973f06 'Pipeline: Groovy'
  * workflow-cps-checkpoint:2.11 'CloudBees Pipeline: Groovy Checkpoint Plugin'
  * workflow-cps-global-lib:566.vd0a_a_3334a_555 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:1128.v8c259d125340 'Pipeline: Nodes and Processes'
  * workflow-job:1174.1176.va_29023983d67 'Pipeline: Job'
  * workflow-multibranch:711.vdfef37cda_816 'Pipeline: Multibranch'
  * workflow-scm-step:2.13 'Pipeline: SCM Step'
  * workflow-step-api:622.vb_8e7c15b_c95a_ 'Pipeline: Step API'
  * workflow-support:817.v58126df57338 'Pipeline: Supporting APIs'

Packaging details
-----------------

#UNKNOWN#

CloudBees Product Description
-----------------------------

 * Product Component: CloudBees Jenkins Enterprise 
 * Product Distribution: rolling 
 * Product Id: cje 
 * Product Name: CloudBees Jenkins Enterprise 
 * Product Solution: CloudBees Jenkins Platform 
 * Product Userfacingsolution: CloudBees Jenkins Platform 
 * Product Version: 2.332.3.4 

CloudBees Distributable Description
-----------------------------------

 * Distributable Name: Debian
 * UDR Commit SHA: c95df68aba7472a024dbdaf0db072b1b1073ab87

License details
---------------

 * Jenkins Instance ID:  `d36bbbfd69d5ea9e18e44aa74c84f4f4`
 * Licensed Instance ID: `*99484d12f5a66d0cdfc15d1fc61720*`
 * Expires:              2022-09-22 23:59:59.000+0000
 * Issued to:            cyberark
 * Organization:         
     - Security
     - Core
     - Enterprise Management
     - CloudBees Jenkins Enterprise licensed for 10 users
